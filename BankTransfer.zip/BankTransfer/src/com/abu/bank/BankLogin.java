package com.abu.bank;

import java.io.*;
import java.sql.*;
import java.util.Enumeration;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/blc")
public class BankLogin extends HttpServlet {
	Connection conn;
	PreparedStatement pstmt;
	String qry= "select name,accno from servlet.bankdb where accno=? and password=?";
	static int accno;
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","root");
			pstmt=conn.prepareStatement(qry);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int accno = Integer.parseInt( req.getParameter("acno"));
		String pass = req.getParameter("pswd");
		
		try {
			pstmt.setInt(1, accno);
			pstmt.setString(2, pass);
			ResultSet rs =pstmt.executeQuery();
			if(rs.next()){
				String name = rs.getString("name");
				int acc = rs.getInt("accno");
				req.setAttribute("nam", name);
				req.setAttribute("ac", acc);
				RequestDispatcher reqdis = req.getRequestDispatcher("btc");
				reqdis.forward(req, resp);
			}else{
				resp.sendRedirect("error.html");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void destroy() {
		super.destroy();
	}
	
}
