package com.abu.bank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/brc")
public class BankReceiverContoller extends HttpServlet {

	Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;
	String dql = "select name from servlet.bankdb where accno = ?";

	@Override
	public void init() throws ServletException {
		super.init();
		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "root");
			pst = con.prepareStatement(dql);
			st = con.createStatement();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		int raccno = Integer.parseInt(req.getParameter("racn"));

		int amt = Integer.parseInt(req.getParameter("amt"));
		int saccno = Integer.parseInt(req.getParameter("sacn"));

		try {
			pst.setInt(1, raccno);
			pst.setInt(1, saccno);
			rs = pst.executeQuery();
			if (rs.next()) {
				try {

					String SDML = "update  servlet.bankdb set amount = amount - " + amt + " where accno=" + saccno + "";
					String RDML = "update servlet.bankdb set amount= amount + "+ amt + " where accno=" + raccno + "";

					st.executeUpdate(SDML);
					st.executeUpdate(RDML);
					String htmlout = "<html>" + "<body>" + "<h1> Amount Transfered is " + amt + "</h1>" + "" + ""
							+ "" + "</body>" + "</html>";

					PrintWriter out = resp.getWriter();
					out.println(htmlout);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} else {
				resp.sendRedirect("error.html");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
