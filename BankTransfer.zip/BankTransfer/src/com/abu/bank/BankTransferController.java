package com.abu.bank;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/btc")
public class BankTransferController extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = (String) req.getAttribute("nam");
		int acc = (int) req.getAttribute("ac");

		String html = "<html><body bgcolor = \"black\">"
				+ "<center><pre>"
				+ "<form method=\"post\" action=\"brc\">"
				+ "<strong><font size='4' color='white'> Your Account No    : </strong></font><input type='text' name='sacn'> <br><br>"
				+ "<strong><font size='4' color='white'> Sender Account No  : </strong></font><input type='text' name='racn'> <br><br>"
				+ "<strong><font size='4' color='white'> Amount             : </strong></font><input type='text' name='amt'>  <br><br>"
				+ "<input type='submit' value = 'Transfer'>&nbsp;&nbsp;&nbsp; <input type='reset' value = 'Reset'> <br><br>"
				+ "<input type='button' value='Logout' onclick='login.html'>"
				+ "</form></pre></center></body></html>";
		
		PrintWriter out = resp.getWriter();
		out.println(html);
	}
}
