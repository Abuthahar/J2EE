package com.abu.jsp;

import java.io.*;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
@WebServlet("/lc")
public class LoginController extends HttpServlet {
	
	Connection conn ; 
	PreparedStatement stmt;
	ResultSet rs;
	
	String qry = "select firstname from servlet.registerdb where email=? and password =? ";
	
	@Override
	public void init() throws ServletException {
		super.init();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn= DriverManager.getConnection("jdbc:mysql://localhost:3306","root","root");
			stmt=conn.prepareStatement(qry);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		 
	}
	
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		String email = req.getParameter("em");
		String pass = req.getParameter("pwd");
		
		try {
			stmt.setString(1, email);
			stmt.setString(2, pass);
			rs = stmt.executeQuery();
			if(rs.next()){
				String name = rs.getString("firstname");
				req.setAttribute("nm", name);
				
				RequestDispatcher rd = req.getRequestDispatcher("display.jsp");
				rd.forward(req, res);
				
			
			
		}else{
			req.setAttribute("emsg", "Invalid email/password");
			
			RequestDispatcher rd = req.getRequestDispatcher("elogin.jsp");
			rd.forward(req, res);
		}
			

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}


}
