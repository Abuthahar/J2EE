package com.abu.jsp;

import java.io.*;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/rc")
public class RegistratonController extends HttpServlet {
	
	Connection conn;
	PreparedStatement pstmt;
	Statement st;
	ResultSet rs;
	String ins = "insert into servlet.registerdb(firstname,lastname,gender,email,password) value(?,?,?,?,?)";
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","root");
			st=conn.createStatement();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String first = req.getParameter("fn");
		String last = req.getParameter("ln");
		String gender = req.getParameter("gen");
		String email = req.getParameter("em");
		String pass = req.getParameter("psw");
		int count=0;

		try {
			 rs = st.executeQuery("select email from servlet.registerdb where email='"+email+"'");
			while(rs.next()){
				String emailid = rs.getString("email");
				 count++;
			}
			if(count==1){

				req.setAttribute("error", "Email is Already Register");
				
				RequestDispatcher rd = req.getRequestDispatcher("error.jsp");
				rd.forward(req, resp);
				
			}else {
				pstmt=conn.prepareStatement(ins);
				pstmt.setString(1, first);
				pstmt.setString(2, last);
				pstmt.setString(3, gender);
				pstmt.setString(4, email);
				pstmt.setString(5, pass);
				pstmt.executeUpdate();
				
				req.setAttribute("msg", "Your Successfully Registered");
				
				RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
				rd.forward(req, resp);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

}
